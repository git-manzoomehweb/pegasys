# jQuery Image Magnifier
An IE6-compliant image magnification tool written for a WebDesignFan publication in 2010.
Now published as a [Medium article](https://medium.com/@Charles_Stover/making-an-image-magnifier-in-jquery-3a67491ba13a),
this repository exists as a live demonstration of the final product.

## Demo
* [GitHub Pages](https://charlesstover.github.io/jquery-image-magnifier/)
